#### Preamble ####
# Purpose: Tests... [...UPDATE THIS...]
# Author: Rohan Alexander [...UPDATE THIS...]
# Date: 11 February 2023 [...UPDATE THIS...]
# Contact: rohan.alexander@utoronto.ca [...UPDATE THIS...]
# License: MIT
# Pre-requisites: [...UPDATE THIS...]
# Any other information needed? [...UPDATE THIS...]


#### Workspace setup ####
library(tidyverse)


#### Test data ####
data <- read_csv("data/raw_data/simulated_data.csv")
# Test for negative number of hate crimes
data$number_of_hate_crime |> min() < 0

# Test for negative date
data$dates |> min() <= 0

# Test for NAs in the number of hate crimes
all(is.na(data$number_of_hate_crime))

